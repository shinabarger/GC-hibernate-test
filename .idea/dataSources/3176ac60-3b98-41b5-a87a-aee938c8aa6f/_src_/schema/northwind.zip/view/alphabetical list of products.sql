CREATE VIEW `alphabetical list of products` AS
  SELECT
    `northwind`.`products`.`ProductID`       AS `ProductID`,
    `northwind`.`products`.`ProductName`     AS `ProductName`,
    `northwind`.`products`.`SupplierID`      AS `SupplierID`,
    `northwind`.`products`.`CategoryID`      AS `CategoryID`,
    `northwind`.`products`.`QuantityPerUnit` AS `QuantityPerUnit`,
    `northwind`.`products`.`UnitPrice`       AS `UnitPrice`,
    `northwind`.`products`.`UnitsInStock`    AS `UnitsInStock`,
    `northwind`.`products`.`UnitsOnOrder`    AS `UnitsOnOrder`,
    `northwind`.`products`.`ReorderLevel`    AS `ReorderLevel`,
    `northwind`.`products`.`Discontinued`    AS `Discontinued`,
    `northwind`.`categories`.`CategoryName`  AS `CategoryName`
  FROM (`northwind`.`categories`
    JOIN `northwind`.`products` ON ((`northwind`.`categories`.`CategoryID` = `northwind`.`products`.`CategoryID`)))
  WHERE (`northwind`.`products`.`Discontinued` = 0)