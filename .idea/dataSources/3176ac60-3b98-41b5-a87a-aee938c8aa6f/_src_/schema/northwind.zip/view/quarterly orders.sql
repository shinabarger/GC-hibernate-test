CREATE VIEW `quarterly orders` AS
  SELECT DISTINCT
    `northwind`.`customers`.`CustomerID`  AS `CustomerID`,
    `northwind`.`customers`.`CompanyName` AS `CompanyName`,
    `northwind`.`customers`.`City`        AS `City`,
    `northwind`.`customers`.`Country`     AS `Country`
  FROM (`northwind`.`customers`
    JOIN `northwind`.`orders` ON ((`northwind`.`customers`.`CustomerID` = `northwind`.`orders`.`CustomerID`)))
  WHERE (`northwind`.`orders`.`OrderDate` BETWEEN '1997-01-01' AND '1997-12-31')