CREATE PROCEDURE `sp_Employees_Update`(IN `AtEmployeeID` INT(11), IN `AtLastName` VARCHAR(20), IN `AtFirstName` VARCHAR(10), IN `AtTitle` VARCHAR(30), IN `AtTitleOfCourtesy` VARCHAR(25),
                                       IN `AtBirthDate`  DATETIME, IN `AtHireDate` DATETIME, IN `AtAddress` VARCHAR(60), IN `AtCity` VARCHAR(15), IN `AtRegion` VARCHAR(15),
                                       IN `AtPostalCode` VARCHAR(10), IN `AtCountry` VARCHAR(15), IN `AtHomePhone` VARCHAR(24), IN `AtExtension` VARCHAR(4), IN `AtPhoto` LONGBLOB,
                                       IN `AtNotes`      MEDIUMTEXT, IN `AtReportsTo` INT(11), IN `AtPhotoPath` VARCHAR(255))
  BEGIN
Update Employees
	Set
		LastName = AtLastName,
		FirstName = AtFirstName,
		Title = AtTitle,
		TitleOfCourtesy = AtTitleOfCourtesy,
		BirthDate = AtBirthDate,
		HireDate = AtHireDate,
		Address = AtAddress,
		City = AtCity,
		Region = AtRegion,
		PostalCode = AtPostalCode,
		Country = AtCountry,
		HomePhone = AtHomePhone,
		Extension = AtExtension,
		Photo = AtPhoto,
		Notes = AtNotes,
		ReportsTo = AtReportsTo,
    PhotoPath = AtPhotoPath
	Where
		EmployeeID = AtEmployeeID;

END