CREATE PROCEDURE `CustOrdersOrders`(IN `AtCustomerID` VARCHAR(5))
  BEGIN
      SELECT OrderID,
	OrderDate,
	RequiredDate,
	ShippedDate
FROM Orders
WHERE CustomerID = AtCustomerID
ORDER BY OrderID;

END